#!/usr/bin/env python3
#
# EPITECH PROJECT, 2023
# WelcomeDayPromo2028
# File description:
# bits.py
#

binary_string = "00010000 00000001 00010100 00001000 00010100 00000101 00001011"

# Sépare les groupes de chiffres binaires :
# binary_list = ____

numbers = []
# Convertit chaque groupe de chiffres binaires en nombre décimal :

print(numbers)

# numbers = [____]

# alphabet = "____"

letters = []

# Convertit chaque nombre en lettre de l'alphabet :

word = ""
print(word)
